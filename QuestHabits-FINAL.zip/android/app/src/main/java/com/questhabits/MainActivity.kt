package com.questhabits

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F5F5F7"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
            setPadding(40, 60, 40, 30)
        }

        val title = TextView(this).apply {
            text = "🎮 QuestHabits"
            textSize = 22f
            setTextColor(Color.parseColor("#1C1C1E"))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(title)

        // Content area
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        // Today's card
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(40, 40, 40, 40)
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 0, 0, 24)
            layoutParams = params
        }

        val cardTitle = TextView(this).apply {
            text = "TODAY'S QUEST"
            textSize = 11f
            setTextColor(Color.parseColor("#6366F1"))
            letterSpacing = 0.1f
        }

        val cardProgress = TextView(this).apply {
            text = "0/5 habits"
            textSize = 28f
            setTextColor(Color.parseColor("#1C1C1E"))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 16, 0, 0)
        }

        card.addView(cardTitle)
        card.addView(cardProgress)

        // Habits list
        val habits = listOf(
            Pair("💪 Morning Workout", "#6366F1"),
            Pair("📚 Read 30 mins", "#0EA5E9"),
            Pair("💧 Drink 2L Water", "#10B981"),
            Pair("🧘 Meditate", "#8B5CF6"),
            Pair("📵 No Social Media", "#F59E0B")
        )

        habits.forEach { (name, color) ->
            val habitRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(Color.WHITE)
                setPadding(32, 28, 32, 28)
                val params = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                params.setMargins(0, 0, 0, 16)
                layoutParams = params
            }

            val habitName = TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(Color.parseColor("#1C1C1E"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            habitRow.addView(habitName)
            content.addView(habitRow)
        }

        content.addView(card)

        layout.addView(header)
        layout.addView(content)

        setContentView(layout)
    }
}
