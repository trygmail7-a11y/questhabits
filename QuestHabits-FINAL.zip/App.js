import React, {useState, useEffect} from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  StyleSheet, SafeAreaView, Alert, StatusBar,
  Linking,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const C = {
  bg:'#F5F5F7', surface:'#FFFFFF', border:'#E5E7EB',
  text:'#1C1C1E', sub:'#6B7280', muted:'#9CA3AF',
  accent:'#6366F1', accentLight:'#EEF2FF',
  amber:'#F59E0B', amberLight:'#FFFBEB',
  green:'#10B981', greenLight:'#ECFDF5',
  red:'#EF4444', blue:'#3B82F6', blueLight:'#EFF6FF',
  purple:'#8B5CF6',
};

const DEFAULT_HABITS = [
  {id:'h1', name:'Morning Workout', color:'#6366F1', xp:50, cat:'Fitness'},
  {id:'h2', name:'Read 30 mins',    color:'#0EA5E9', xp:40, cat:'Learning'},
  {id:'h3', name:'Drink 2L Water',  color:'#10B981', xp:30, cat:'Health'},
  {id:'h4', name:'Meditate',        color:'#8B5CF6', xp:35, cat:'Mindfulness'},
  {id:'h5', name:'No Social Media', color:'#F59E0B', xp:45, cat:'Digital'},
];

const LINKS = [
  {label:'Privacy Policy',     url:'https://questhabitsprivacy.blogspot.com'},
  {label:'Terms & Conditions', url:'https://questhabitsterm.blogspot.com'},
  {label:'About Us',           url:'https://questhabitsabout.blogspot.com'},
  {label:'Contact Us',         url:'https://questhabitscontact.blogspot.com'},
];

const today = () => new Date().toISOString().slice(0,10);

const Storage = {
  get: async (k, fb) => {
    try { const v = await AsyncStorage.getItem(k); return v ? JSON.parse(v) : fb; }
    catch { return fb; }
  },
  set: async (k, v) => { try { await AsyncStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

export default function App() {
  const [habits]   = useState(DEFAULT_HABITS);
  const [log,      setLog]     = useState({});
  const [totalXP,  setTotalXP] = useState(0);
  const [streak,   setStreak]  = useState(0);
  const [freezes,  setFreezes] = useState(0);
  const [toast,    setToast]   = useState(null);
  const [todayCount, setTodayCount] = useState(0);

  const todayKey  = today();
  const todayDone = new Set(log[todayKey] || []);
  const todayPct  = Math.round(todayDone.size / habits.length * 100);
  const level     = Math.floor(totalXP / 300) + 1;

  useEffect(() => {
    (async () => {
      const [l, xp, st, fr, tc] = await Promise.all([
        Storage.get('qh_log', {}),
        Storage.get('qh_txp', 0),
        Storage.get('qh_streak', 0),
        Storage.get('qh_freezes', 0),
        Storage.get('qh_tc_' + todayKey, 0),
      ]);
      setLog(l); setTotalXP(xp); setStreak(st);
      setFreezes(fr); setTodayCount(tc);
    })();
  }, []);

  const showToast = (msg, color = C.green) => {
    setToast({msg, color});
    setTimeout(() => setToast(null), 2500);
  };

  const toggleHabit = async (h) => {
    const nd = new Set(todayDone);
    let newXP = totalXP;
    let nc = todayCount;
    if (nd.has(h.id)) {
      nd.delete(h.id); newXP = Math.max(0, totalXP - h.xp);
      nc = Math.max(0, nc - 1);
      showToast('-' + h.xp + ' XP', C.red);
    } else {
      nd.add(h.id); newXP = totalXP + h.xp; nc = nc + 1;
      showToast('+' + h.xp + ' XP!', C.green);
      if (nc % 3 === 0) {
        setTimeout(() => {
          Alert.alert('Bonus XP!', 'Watch an ad to get +50 Bonus XP', [
            {text: 'Skip'},
            {text: 'Watch Ad', onPress: () => showToast('+50 Bonus XP! (Ad watched)', C.purple)},
          ]);
        }, 500);
      }
      if (nd.size === habits.length) {
        const ns = streak + 1;
        setStreak(ns); await Storage.set('qh_streak', ns);
        showToast(ns + '-day streak! 🔥', C.amber);
      }
    }
    const newLog = {...log, [todayKey]: [...nd]};
    setLog(newLog); setTotalXP(newXP); setTodayCount(nc);
    await Promise.all([
      Storage.set('qh_log', newLog),
      Storage.set('qh_txp', newXP),
      Storage.set('qh_tc_' + todayKey, nc),
    ]);
  };

  const showFreezeAd = () => {
    Alert.alert('Streak Freeze', 'Watch an ad to get 1 Streak Freeze!', [
      {text: 'Cancel'},
      {text: 'Watch Ad', onPress: async () => {
        const nf = freezes + 1;
        setFreezes(nf); await Storage.set('qh_freezes', nf);
        showToast('Streak Freeze added!', C.blue);
      }},
    ]);
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      {toast && <View style={[s.toast, {backgroundColor: toast.color}]}><Text style={s.toastTxt}>{toast.msg}</Text></View>}

      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.appName}>QUESTHABITS</Text>
          <Text style={s.greeting}>{todayPct === 100 ? 'All done! 🎉' : 'Keep going! 💪'}</Text>
        </View>
        <View style={s.pills}>
          <View style={[s.pill, {backgroundColor: C.amberLight}]}>
            <Text style={[s.pillTxt, {color: C.amber}]}>🔥 {streak}</Text>
          </View>
          <View style={[s.pill, {backgroundColor: C.accentLight}]}>
            <Text style={[s.pillTxt, {color: C.accent}]}>⚡ Lv {level}</Text>
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={s.content}>

        {/* Today Card */}
        <View style={[s.card, {borderTopColor: C.accent, borderTopWidth: 3}]}>
          <Text style={s.label}>TODAY'S QUEST</Text>
          <View style={s.row}>
            <View>
              <Text style={s.bigNum}>{todayDone.size}<Text style={s.bigSub}>/{habits.length}</Text></Text>
              <Text style={s.sub}>{new Date().toLocaleDateString('en-IN', {weekday:'long', day:'numeric', month:'short'})}</Text>
            </View>
            <View style={[s.circle, {borderColor: todayPct === 100 ? C.green : C.accent}]}>
              <Text style={[s.circleTxt, {color: todayPct === 100 ? C.green : C.accent}]}>{todayPct}%</Text>
            </View>
          </View>
          <View style={s.barBg}>
            <View style={[s.barFill, {width: todayPct + '%', backgroundColor: todayPct === 100 ? C.green : C.accent}]} />
          </View>
        </View>

        {/* Bonus XP Info */}
        <View style={s.infoStrip}>
          <Text style={s.infoTxt}>🎁 Every 3rd habit → Watch Ad → +50 Bonus XP</Text>
        </View>

        {/* Habits */}
        <Text style={s.secLabel}>MY HABITS</Text>
        {habits.map(h => {
          const isDone = todayDone.has(h.id);
          return (
            <TouchableOpacity key={h.id} onPress={() => toggleHabit(h)} activeOpacity={0.7}
              style={[s.habitRow, {borderColor: isDone ? h.color + '60' : C.border}]}>
              <View style={[s.habitIcon, {backgroundColor: isDone ? h.color : h.color + '20'}]}>
                <Text style={{fontSize: 20}}>{isDone ? '✓' : '○'}</Text>
              </View>
              <View style={{flex: 1}}>
                <Text style={[s.habitName, {opacity: isDone ? 0.5 : 1, textDecorationLine: isDone ? 'line-through' : 'none'}]}>{h.name}</Text>
                <Text style={s.habitMeta}>{h.cat} · <Text style={{color: C.amber, fontWeight: '700'}}>+{h.xp} XP</Text></Text>
              </View>
              <View style={[s.checkbox, {borderColor: isDone ? h.color : C.border, backgroundColor: isDone ? h.color : 'transparent'}]}>
                {isDone && <Text style={{color: '#fff', fontWeight: '800', fontSize: 13}}>✓</Text>}
              </View>
            </TouchableOpacity>
          );
        })}

        {/* Streak Freeze */}
        <View style={s.card}>
          <View style={{flexDirection: 'row', alignItems: 'center', gap: 12}}>
            <View style={[s.iconBox, {backgroundColor: C.blueLight}]}>
              <Text style={{fontSize: 22}}>🧊</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={s.freezeTitle}>Streak Freeze</Text>
              <Text style={s.freezeSub}><Text style={{color: C.blue, fontWeight: '700'}}>{freezes}</Text> freeze — saves streak on missed days</Text>
            </View>
            <TouchableOpacity onPress={showFreezeAd} style={[s.watchBtn, {backgroundColor: C.blueLight}]}>
              <Text style={{color: C.blue, fontWeight: '700', fontSize: 13}}>▶ Watch Ad</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Stats */}
        <View style={s.statsRow}>
          {[
            {label: 'Total XP', value: totalXP, color: C.amber},
            {label: 'Streak',   value: streak + '🔥', color: '#F97316'},
            {label: 'Level',    value: 'Lv ' + level, color: C.accent},
          ].map(st => (
            <View key={st.label} style={s.statCard}>
              <Text style={[s.statVal, {color: st.color}]}>{st.value}</Text>
              <Text style={s.statLbl}>{st.label}</Text>
            </View>
          ))}
        </View>

        {/* Links */}
        <Text style={[s.secLabel, {marginTop: 16}]}>QUICK LINKS</Text>
        {LINKS.map(l => (
          <TouchableOpacity key={l.url} onPress={() => Linking.openURL(l.url)} style={s.linkRow}>
            <Text style={s.linkLabel}>{l.label}</Text>
            <Text style={{color: C.muted, fontSize: 18}}>›</Text>
          </TouchableOpacity>
        ))}

        <View style={{height: 30}} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:       {flex: 1, backgroundColor: C.bg},
  header:     {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.border},
  appName:    {fontSize: 10, fontWeight: '700', color: C.accent, letterSpacing: 1.5},
  greeting:   {fontSize: 18, fontWeight: '800', color: C.text},
  pills:      {flexDirection: 'row', gap: 8},
  pill:       {borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5},
  pillTxt:    {fontWeight: '800', fontSize: 13},
  toast:      {position: 'absolute', top: 60, alignSelf: 'center', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 99, zIndex: 999},
  toastTxt:   {color: '#fff', fontWeight: '700', fontSize: 14},
  content:    {padding: 16},
  card:       {backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 16, marginBottom: 12, elevation: 2},
  label:      {fontSize: 10, fontWeight: '700', color: C.accent, letterSpacing: 1.2, marginBottom: 10},
  row:        {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12},
  bigNum:     {fontSize: 28, fontWeight: '900', color: C.text},
  bigSub:     {fontSize: 15, fontWeight: '400', color: C.muted},
  sub:        {fontSize: 12, color: C.sub, marginTop: 2},
  circle:     {width: 64, height: 64, borderRadius: 32, borderWidth: 3, alignItems: 'center', justifyContent: 'center'},
  circleTxt:  {fontSize: 17, fontWeight: '900'},
  barBg:      {backgroundColor: '#F3F4F6', borderRadius: 99, height: 8, overflow: 'hidden'},
  barFill:    {height: '100%', borderRadius: 99},
  infoStrip:  {backgroundColor: '#F5F3FF', borderRadius: 12, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: '#C7D2FE'},
  infoTxt:    {fontSize: 13, fontWeight: '600', color: C.purple},
  secLabel:   {fontSize: 10, fontWeight: '700', color: C.sub, letterSpacing: 1.2, marginBottom: 10},
  habitRow:   {flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff', borderWidth: 1, borderRadius: 14, padding: 13, marginBottom: 10, elevation: 1},
  habitIcon:  {width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  habitName:  {fontWeight: '700', fontSize: 14, color: C.text},
  habitMeta:  {fontSize: 12, color: C.muted, marginTop: 2},
  checkbox:   {width: 28, height: 28, borderRadius: 14, borderWidth: 2, alignItems: 'center', justifyContent: 'center'},
  iconBox:    {width: 46, height: 46, borderRadius: 13, alignItems: 'center', justifyContent: 'center'},
  freezeTitle:{fontWeight: '700', fontSize: 14, color: C.text},
  freezeSub:  {fontSize: 12, color: C.sub, marginTop: 2},
  watchBtn:   {borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8},
  statsRow:   {flexDirection: 'row', gap: 10, marginTop: 4},
  statCard:   {flex: 1, backgroundColor: '#fff', borderRadius: 14, borderWidth: 1, borderColor: C.border, padding: 12, alignItems: 'center', elevation: 1},
  statVal:    {fontSize: 18, fontWeight: '900'},
  statLbl:    {fontSize: 10, color: C.muted, marginTop: 3},
  linkRow:    {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: C.border, padding: 14, marginBottom: 8, elevation: 1},
  linkLabel:  {fontWeight: '600', fontSize: 14, color: C.text},
});
