# QuestHabits - React Native App

## AdMob IDs (Already configured)
- App ID:                  ca-app-pub-5501173604593097~8792146232
- Interstitial:            ca-app-pub-5501173604593097/9775688328
- Rewarded:                ca-app-pub-5501173604593097/6770251036
- Rewarded Interstitial:   ca-app-pub-5501173604593097/4714933334

## Setup Steps
1. npm install
2. eas build --platform android
