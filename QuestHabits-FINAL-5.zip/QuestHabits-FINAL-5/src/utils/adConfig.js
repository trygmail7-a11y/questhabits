import { Platform } from 'react-native';

const PROD = {
  android: {
    INTERSTITIAL:          'ca-app-pub-5501173604593097/9775688328',
    REWARDED:              'ca-app-pub-5501173604593097/6770251036',
    REWARDED_INTERSTITIAL: 'ca-app-pub-5501173604593097/4714933334',
    BANNER:                'ca-app-pub-5501173604593097/9775688328',
  },
  ios: {
    INTERSTITIAL:          'ca-app-pub-5501173604593097/9775688328',
    REWARDED:              'ca-app-pub-5501173604593097/6770251036',
    REWARDED_INTERSTITIAL: 'ca-app-pub-5501173604593097/4714933334',
    BANNER:                'ca-app-pub-5501173604593097/9775688328',
  },
};

const TEST = {
  BANNER:                'ca-app-pub-3940256099942544/6300978111',
  INTERSTITIAL:          'ca-app-pub-3940256099942544/1033173712',
  REWARDED:              'ca-app-pub-3940256099942544/5224354917',
  REWARDED_INTERSTITIAL: 'ca-app-pub-3940256099942544/2247696110',
};

const IS_DEV = __DEV__;
const OS = Platform.OS;

export const AD_IDS = {
  BANNER:                IS_DEV ? TEST.BANNER                : PROD[OS].BANNER,
  INTERSTITIAL:          IS_DEV ? TEST.INTERSTITIAL          : PROD[OS].INTERSTITIAL,
  REWARDED:              IS_DEV ? TEST.REWARDED              : PROD[OS].REWARDED,
  REWARDED_INTERSTITIAL: IS_DEV ? TEST.REWARDED_INTERSTITIAL : PROD[OS].REWARDED_INTERSTITIAL,
};

export const REWARDED_BONUS_XP    = 50;
export const MAX_REWARDED_PER_DAY = 5;
