import AsyncStorage from '@react-native-async-storage/async-storage';

export const Storage = {
  get: async (key, fallback = null) => {
    try { const v = await AsyncStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  set: async (key, value) => {
    try { await AsyncStorage.setItem(key, JSON.stringify(value)); }
    catch (e) { console.warn('Storage error:', e); }
  },
};

export const today = () => new Date().toISOString().slice(0, 10);
export const daysBetween = (a, b) => Math.floor((new Date(a) - new Date(b)) / 86400000);
