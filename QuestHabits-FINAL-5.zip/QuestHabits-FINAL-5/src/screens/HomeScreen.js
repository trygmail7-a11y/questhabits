// ── HOME SCREEN — All 4 AdMob Ads integrated ──
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, StyleSheet,
  Alert, ActivityIndicator, SafeAreaView, Image, Linking,
} from 'react-native';
import { Storage, today, daysBetween } from '../utils/storage';
import { REWARDED_BONUS_XP }           from '../utils/adConfig';
import { useInterstitialAd }            from '../components/useInterstitialAd';
import { useRewardedAd }                from '../components/useRewardedAd';
import { useRewardedInterstitialAd }    from '../components/useRewardedInterstitialAd';
import BannerAdView                     from '../components/BannerAdView';

const C = {
  bg:'#F5F5F7', surface:'#FFFFFF', border:'#E5E7EB',
  text:'#1C1C1E', sub:'#6B7280', muted:'#9CA3AF',
  accent:'#6366F1', accentLight:'#EEF2FF',
  amber:'#F59E0B', amberLight:'#FFFBEB',
  green:'#10B981', greenLight:'#ECFDF5',
  red:'#EF4444', blue:'#3B82F6', blueLight:'#EFF6FF',
  purple:'#8B5CF6',
};

const DEFAULT_HABITS = [
  { id:'h1', name:'Morning Workout', color:'#6366F1', xp:50, cat:'Fitness' },
  { id:'h2', name:'Read 30 mins',    color:'#0EA5E9', xp:40, cat:'Learning' },
  { id:'h3', name:'Drink 2L Water',  color:'#10B981', xp:30, cat:'Health' },
  { id:'h4', name:'Meditate',        color:'#8B5CF6', xp:35, cat:'Mindfulness' },
  { id:'h5', name:'No Social Media', color:'#F59E0B', xp:45, cat:'Digital' },
];

const LINKS = [
  { label:'Privacy Policy',    url:'https://questhabitsprivacy.blogspot.com' },
  { label:'Terms & Conditions',url:'https://questhabitsterm.blogspot.com' },
  { label:'About Us',          url:'https://questhabitsabout.blogspot.com' },
  { label:'Contact Us',        url:'https://questhabitscontact.blogspot.com' },
];

export default function HomeScreen() {
  const [habits,   setHabits]  = useState(DEFAULT_HABITS);
  const [log,      setLog]     = useState({});
  const [totalXP,  setTotalXP] = useState(0);
  const [streak,   setStreak]  = useState(0);
  const [freezes,  setFreezes] = useState(0);
  const [loading,  setLoading] = useState(true);
  const [toast,    setToast]   = useState(null);
  const [todayCount, setTodayCount] = useState(0);

  const todayKey  = today();
  const todayDone = new Set(log[todayKey] || []);
  const todayPct  = habits.length ? Math.round(todayDone.size / habits.length * 100) : 0;
  const level     = Math.floor(totalXP / 300) + 1;

  // ── AD HOOKS ──
  const { showIfDue }      = useInterstitialAd();
  const { showAd }         = useRewardedAd();
  const { showAd: showRI } = useRewardedInterstitialAd();

  // ── LOAD DATA ──
  useEffect(() => {
    (async () => {
      const [h, l, xp, st, fr, tc, lastDate] = await Promise.all([
        Storage.get('qh_habits',  DEFAULT_HABITS),
        Storage.get('qh_log',     {}),
        Storage.get('qh_txp',     0),
        Storage.get('qh_streak',  0),
        Storage.get('qh_freezes', 0),
        Storage.get(`qh_tc_${todayKey}`, 0),
        Storage.get('qh_lastdate',''),
      ]);
      setHabits(h); setLog(l); setTotalXP(xp);
      setStreak(st); setFreezes(fr); setTodayCount(tc);
      setLoading(false);

      // Streak check
      if (lastDate && lastDate !== todayKey) {
        const diff = daysBetween(todayKey, lastDate);
        if (diff > 1) {
          const missed = diff - 1;
          if (fr >= missed) {
            const nf = fr - missed;
            setFreezes(nf); await Storage.set('qh_freezes', nf);
            showToast(`Streak Freeze x${missed} used — streak saved!`, C.blue);
          } else {
            setStreak(0); await Storage.set('qh_streak', 0);
            showToast('Streak reset — keep going!', C.red);
          }
        }
      }

      // AD 1: Interstitial — din mein ek baar
      setTimeout(() => showIfDue(), 1500);
    })();
  }, []);

  const showToast = (msg, color = C.green) => {
    setToast({ msg, color });
    setTimeout(() => setToast(null), 2500);
  };

  // ── TOGGLE HABIT ──
  const toggleHabit = useCallback(async (habit) => {
    const nd = new Set(todayDone);
    let newXP = totalXP;
    let nc    = todayCount;

    if (nd.has(habit.id)) {
      nd.delete(habit.id); newXP = Math.max(0, totalXP - habit.xp);
      nc = Math.max(0, nc - 1); showToast(`-${habit.xp} XP`, C.red);
    } else {
      nd.add(habit.id); newXP = totalXP + habit.xp; nc = nc + 1;
      showToast(`+${habit.xp} XP!`, C.green);

      // AD 2: Rewarded — har 3rd habit complete par
      if (nc % 3 === 0) {
        setTimeout(() => {
          Alert.alert(
            'Bonus XP Available!',
            `You completed ${nc} habits! Watch a short ad to earn +${REWARDED_BONUS_XP} Bonus XP.`,
            [
              { text: 'Skip', style: 'cancel' },
              { text: `Watch Ad → +${REWARDED_BONUS_XP} XP`, onPress: () => showRewardedForXP(newXP) },
            ]
          );
        }, 800);
      }

      // Streak
      if (nd.size === habits.length) {
        const lastDate = await Storage.get('qh_lastdate', '');
        const diff = lastDate ? daysBetween(todayKey, lastDate) : 1;
        const ns = diff <= 1 ? streak + 1 : 1;
        setStreak(ns); await Storage.set('qh_streak', ns);
        if (ns > 1) showToast(`${ns}-day streak!`, C.amber);
      }
    }

    const newLog = { ...log, [todayKey]: [...nd] };
    setLog(newLog); setTotalXP(newXP); setTodayCount(nc);
    await Promise.all([
      Storage.set('qh_log', newLog),
      Storage.set('qh_txp', newXP),
      Storage.set('qh_lastdate', todayKey),
      Storage.set(`qh_tc_${todayKey}`, nc),
    ]);
  }, [todayDone, totalXP, streak, habits, todayCount, log]);

  // AD 2: Rewarded → +50 Bonus XP
  const showRewardedForXP = async (currentXP = totalXP) => {
    const result = await showAd(async () => {
      const nXP = currentXP + REWARDED_BONUS_XP;
      setTotalXP(nXP); await Storage.set('qh_txp', nXP);
      showToast(`+${REWARDED_BONUS_XP} Bonus XP!`, C.purple);
    });
    if (!result.success) {
      if (result.reason === 'daily_limit') showToast('Daily ad limit reached', C.muted);
      else showToast('Ad loading… try again', C.muted);
    }
  };

  // AD 3: Rewarded Interstitial → Streak Freeze
  const showFreezeAd = async () => {
    Alert.alert(
      'Get Streak Freeze',
      'Watch a short ad to protect your streak on days you miss.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Watch Ad → Get Freeze',
          onPress: async () => {
            const result = await showRI(async () => {
              const nf = freezes + 1;
              setFreezes(nf); await Storage.set('qh_freezes', nf);
              showToast('Streak Freeze added!', C.blue);
            });
            if (!result.success) showToast('Ad not ready, try again', C.muted);
          },
        },
      ]
    );
  };

  if (loading) return (
    <View style={[s.container, { justifyContent:'center', alignItems:'center' }]}>
      <ActivityIndicator size="large" color={C.accent} />
    </View>
  );

  return (
    <SafeAreaView style={s.safeArea}>
      {/* Toast */}
      {toast && <View style={[s.toast, { backgroundColor: toast.color }]}><Text style={s.toastText}>{toast.msg}</Text></View>}

      {/* Header */}
      <View style={s.header}>
        <View style={s.headerLeft}>
          <Image source={require('../../assets/logo.png')} style={s.logo} />
          <View>
            <Text style={s.appName}>QUESTHABITS</Text>
            <Text style={s.greeting}>{todayPct === 100 ? 'All done! 🎉' : 'Keep going! 💪'}</Text>
          </View>
        </View>
        <View style={s.pills}>
          <View style={[s.pill, { backgroundColor: C.amberLight }]}>
            <Text style={[s.pillTxt, { color: C.amber }]}>🔥 {streak}</Text>
          </View>
          <View style={[s.pill, { backgroundColor: C.accentLight }]}>
            <Text style={[s.pillTxt, { color: C.accent }]}>⚡ Lv {level}</Text>
          </View>
        </View>
      </View>

      <ScrollView style={{ flex:1 }} contentContainerStyle={{ padding:16, paddingBottom:20 }}>

        {/* Today progress */}
        <View style={[s.card, { borderTopColor: C.accent, borderTopWidth: 3 }]}>
          <View style={s.progressRow}>
            <View>
              <Text style={s.label}>TODAY'S QUEST</Text>
              <Text style={s.bigNum}>{todayDone.size}<Text style={s.bigNumSub}>/{habits.length}</Text></Text>
              <Text style={s.sub}>{new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'short'})}</Text>
            </View>
            <View style={[s.circle, { borderColor: todayPct===100 ? C.green : C.accent }]}>
              <Text style={[s.circleTxt, { color: todayPct===100 ? C.green : C.accent }]}>{todayPct}%</Text>
            </View>
          </View>
          <View style={s.barBg}><View style={[s.barFill, { width:`${todayPct}%`, backgroundColor: todayPct===100 ? C.green : C.accent }]} /></View>
        </View>

        {/* Bonus XP strip */}
        <View style={s.strip}>
          <Text style={[s.stripTxt, { color: C.purple }]}>🎁 Every 3rd habit → Watch Ad → +{REWARDED_BONUS_XP} Bonus XP</Text>
        </View>

        {/* Habits */}
        <Text style={s.sectionLabel}>MY HABITS</Text>
        {habits.map(h => {
          const isDone = todayDone.has(h.id);
          return (
            <TouchableOpacity key={h.id} activeOpacity={0.7} onPress={() => toggleHabit(h)}
              style={[s.habitRow, { borderColor: isDone ? h.color+'60' : C.border }]}>
              <View style={[s.habitIcon, { backgroundColor: isDone ? h.color : h.color+'20' }]}>
                <Text style={{ fontSize:20, color: isDone?'#fff':h.color }}>{isDone?'✓':'○'}</Text>
              </View>
              <View style={{ flex:1 }}>
                <Text style={[s.habitName, { opacity: isDone?0.5:1, textDecorationLine: isDone?'line-through':'none' }]}>{h.name}</Text>
                <Text style={s.habitMeta}>{h.cat} · <Text style={{ color:C.amber, fontWeight:'700' }}>+{h.xp} XP</Text></Text>
              </View>
              <View style={[s.checkbox, { borderColor: isDone?h.color:C.border, backgroundColor: isDone?h.color:'transparent' }]}>
                {isDone && <Text style={{ color:'#fff', fontWeight:'800' }}>✓</Text>}
              </View>
            </TouchableOpacity>
          );
        })}

        {/* Streak Freeze — AD 3 */}
        <View style={s.card}>
          <View style={{ flexDirection:'row', alignItems:'center', gap:14 }}>
            <View style={[s.freezeIcon, { backgroundColor: C.blueLight }]}><Text style={{ fontSize:22 }}>🧊</Text></View>
            <View style={{ flex:1 }}>
              <Text style={s.freezeTitle}>Streak Freeze</Text>
              <Text style={s.freezeSub}><Text style={{ color:C.blue, fontWeight:'700' }}>{freezes}</Text> freeze{freezes!==1?'s':''} · protects missed days</Text>
            </View>
            <TouchableOpacity onPress={showFreezeAd} style={[s.watchBtn, { backgroundColor:C.blueLight }]}>
              <Text style={[s.watchBtnTxt, { color:C.blue }]}>▶ Watch Ad</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Stats */}
        <View style={s.statsRow}>
          {[
            { label:'Total XP', value:totalXP,     color:C.amber  },
            { label:'Streak',   value:`${streak}🔥`,color:'#F97316'},
            { label:'Level',    value:`Lv ${level}`,color:C.accent },
          ].map(st => (
            <View key={st.label} style={s.statCard}>
              <Text style={[s.statVal, { color:st.color }]}>{st.value}</Text>
              <Text style={s.statLbl}>{st.label}</Text>
            </View>
          ))}
        </View>

        {/* Links */}
        <Text style={[s.sectionLabel, { marginTop:16 }]}>QUICK LINKS</Text>
        {LINKS.map(l => (
          <TouchableOpacity key={l.url} onPress={() => Linking.openURL(l.url)}
            style={[s.linkRow]}>
            <Text style={s.linkLabel}>{l.label}</Text>
            <Text style={{ color:C.muted, fontSize:18 }}>›</Text>
          </TouchableOpacity>
        ))}

        <View style={{ height:20 }} />
      </ScrollView>

      {/* AD 4: Banner — hamesha bottom par */}
      <BannerAdView />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safeArea:    { flex:1, backgroundColor:'#F5F5F7' },
  container:   { flex:1, backgroundColor:'#F5F5F7' },
  header:      { flexDirection:'row', justifyContent:'space-between', alignItems:'center', backgroundColor:'#fff', paddingHorizontal:16, paddingVertical:12, borderBottomWidth:1, borderBottomColor:'#E5E7EB' },
  headerLeft:  { flexDirection:'row', alignItems:'center', gap:10 },
  logo:        { width:36, height:36, borderRadius:10 },
  appName:     { fontSize:10, fontWeight:'700', color:'#6366F1', letterSpacing:1.5 },
  greeting:    { fontSize:18, fontWeight:'800', color:'#1C1C1E', marginTop:1 },
  pills:       { flexDirection:'row', gap:8 },
  pill:        { flexDirection:'row', alignItems:'center', borderRadius:99, paddingHorizontal:10, paddingVertical:5 },
  pillTxt:     { fontWeight:'800', fontSize:13 },
  toast:       { position:'absolute', top:70, alignSelf:'center', paddingHorizontal:20, paddingVertical:10, borderRadius:99, zIndex:999 },
  toastText:   { color:'#fff', fontWeight:'700', fontSize:14 },
  card:        { backgroundColor:'#fff', borderRadius:18, borderWidth:1, borderColor:'#E5E7EB', padding:16, marginBottom:12, shadowColor:'#000', shadowOpacity:0.04, shadowRadius:6, elevation:2 },
  label:       { fontSize:10, fontWeight:'700', color:'#6366F1', letterSpacing:1.2, marginBottom:8 },
  progressRow: { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:12 },
  bigNum:      { fontSize:28, fontWeight:'900', color:'#1C1C1E' },
  bigNumSub:   { fontSize:15, fontWeight:'400', color:'#9CA3AF' },
  sub:         { fontSize:12, color:'#6B7280', marginTop:2 },
  circle:      { width:64, height:64, borderRadius:32, borderWidth:3, alignItems:'center', justifyContent:'center' },
  circleTxt:   { fontSize:17, fontWeight:'900' },
  barBg:       { backgroundColor:'#F3F4F6', borderRadius:99, height:8, overflow:'hidden' },
  barFill:     { height:'100%', borderRadius:99 },
  strip:       { backgroundColor:'#F5F3FF', borderRadius:12, padding:12, marginBottom:12, borderWidth:1, borderColor:'#C7D2FE' },
  stripTxt:    { fontSize:13, fontWeight:'600' },
  sectionLabel:{ fontSize:10, fontWeight:'700', color:'#6B7280', letterSpacing:1.2, marginBottom:10 },
  habitRow:    { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:'#fff', borderWidth:1, borderRadius:14, padding:13, marginBottom:10, elevation:1 },
  habitIcon:   { width:44, height:44, borderRadius:12, alignItems:'center', justifyContent:'center' },
  habitName:   { fontWeight:'700', fontSize:14, color:'#1C1C1E' },
  habitMeta:   { fontSize:12, color:'#9CA3AF', marginTop:2 },
  checkbox:    { width:28, height:28, borderRadius:14, borderWidth:2, alignItems:'center', justifyContent:'center' },
  freezeIcon:  { width:46, height:46, borderRadius:13, alignItems:'center', justifyContent:'center' },
  freezeTitle: { fontWeight:'700', fontSize:14, color:'#1C1C1E' },
  freezeSub:   { fontSize:12, color:'#6B7280', marginTop:2 },
  watchBtn:    { borderRadius:10, paddingHorizontal:12, paddingVertical:8 },
  watchBtnTxt: { fontWeight:'700', fontSize:13 },
  statsRow:    { flexDirection:'row', gap:10, marginTop:4 },
  statCard:    { flex:1, backgroundColor:'#fff', borderRadius:14, borderWidth:1, borderColor:'#E5E7EB', padding:12, alignItems:'center', elevation:1 },
  statVal:     { fontSize:18, fontWeight:'900' },
  statLbl:     { fontSize:10, color:'#9CA3AF', marginTop:3 },
  linkRow:     { flexDirection:'row', alignItems:'center', justifyContent:'space-between', backgroundColor:'#fff', borderRadius:12, borderWidth:1, borderColor:'#E5E7EB', padding:14, marginBottom:8, elevation:1 },
  linkLabel:   { fontWeight:'600', fontSize:14, color:'#1C1C1E' },
});
