// ── REWARDED AD ── 3rd habit par (+50 XP) aur Streak Freeze ke liye
import { useEffect, useRef, useState } from 'react';
import { RewardedAd, RewardedAdEventType, AdEventType } from 'react-native-google-mobile-ads';
import { AD_IDS, MAX_REWARDED_PER_DAY } from '../utils/adConfig';
import { Storage, today } from '../utils/storage';

export function useRewardedAd() {
  const [isLoaded,  setIsLoaded]  = useState(false);
  const [isShowing, setIsShowing] = useState(false);
  const rewardCb = useRef(null);

  const ad = useRef(
    RewardedAd.createForAdRequest(AD_IDS.REWARDED, {
      keywords: ['health', 'fitness', 'habit', 'productivity'],
    })
  ).current;

  useEffect(() => {
    const onLoaded  = ad.addAdEventListener(RewardedAdEventType.LOADED,        () => setIsLoaded(true));
    const onEarned  = ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD,  (r) => { rewardCb.current?.(r); rewardCb.current = null; });
    const onClosed  = ad.addAdEventListener(AdEventType.CLOSED,                () => { setIsLoaded(false); setIsShowing(false); ad.load(); });
    const onError   = ad.addAdEventListener(AdEventType.ERROR,                 (e) => { console.warn('Rewarded err:', e); setIsLoaded(false); setIsShowing(false); });
    ad.load();
    return () => { onLoaded(); onEarned(); onClosed(); onError(); };
  }, []);

  const showAd = async (onReward) => {
    const count = await Storage.get(`rewarded_count_${today()}`, 0);
    if (count >= MAX_REWARDED_PER_DAY) return { success: false, reason: 'daily_limit' };
    if (!isLoaded)  return { success: false, reason: 'not_loaded' };
    if (isShowing)  return { success: false, reason: 'already_showing' };
    rewardCb.current = onReward;
    setIsShowing(true);
    await Storage.set(`rewarded_count_${today()}`, count + 1);
    try { await ad.show(); return { success: true }; }
    catch (e) { setIsShowing(false); rewardCb.current = null; return { success: false, reason: e.message }; }
  };

  return { showAd, isLoaded, isShowing };
}
