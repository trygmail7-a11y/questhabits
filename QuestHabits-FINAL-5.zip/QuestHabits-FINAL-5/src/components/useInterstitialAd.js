// ── INTERSTITIAL AD ── App open par din mein ek baar
import { useEffect, useRef } from 'react';
import { InterstitialAd, AdEventType } from 'react-native-google-mobile-ads';
import { AD_IDS } from '../utils/adConfig';
import { Storage, today } from '../utils/storage';

export function useInterstitialAd() {
  const ad = useRef(
    InterstitialAd.createForAdRequest(AD_IDS.INTERSTITIAL, {
      keywords: ['health', 'fitness', 'habit', 'productivity'],
    })
  ).current;

  useEffect(() => {
    const onLoaded = ad.addAdEventListener(AdEventType.LOADED,  () => console.log('Interstitial loaded'));
    const onClosed = ad.addAdEventListener(AdEventType.CLOSED,  () => ad.load());
    const onError  = ad.addAdEventListener(AdEventType.ERROR,   (e) => console.warn('Interstitial err:', e));
    ad.load();
    return () => { onLoaded(); onClosed(); onError(); };
  }, []);

  const showIfDue = async () => {
    const last = await Storage.get('interstitial_last_date', '');
    if (last === today()) return;
    try { await ad.show(); await Storage.set('interstitial_last_date', today()); }
    catch (e) { console.warn('Interstitial not ready:', e); }
  };

  return { showIfDue };
}
