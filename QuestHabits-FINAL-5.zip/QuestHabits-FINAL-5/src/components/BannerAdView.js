// ── BANNER AD ── hamesha bottom par dikhta hai
import React from 'react';
import { View, StyleSheet } from 'react-native';
import { BannerAd, BannerAdSize } from 'react-native-google-mobile-ads';
import { AD_IDS } from '../utils/adConfig';

export default function BannerAdView() {
  return (
    <View style={styles.wrap}>
      <BannerAd
        unitId={AD_IDS.BANNER}
        size={BannerAdSize.ADAPTIVE_BANNER}
        requestOptions={{ keywords: ['health','fitness','habit','productivity'] }}
        onAdLoaded={() => console.log('Banner loaded')}
        onAdFailedToLoad={(e) => console.warn('Banner failed:', e)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#E5E7EB' },
});
