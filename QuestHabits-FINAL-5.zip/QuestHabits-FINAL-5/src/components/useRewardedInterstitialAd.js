// ── REWARDED INTERSTITIAL AD ── Full screen rewarded (Freeze ke liye)
import { useEffect, useRef, useState } from 'react';
import { RewardedInterstitialAd, RewardedAdEventType, AdEventType } from 'react-native-google-mobile-ads';
import { AD_IDS } from '../utils/adConfig';

export function useRewardedInterstitialAd() {
  const [isLoaded, setIsLoaded] = useState(false);
  const rewardCb = useRef(null);

  const ad = useRef(
    RewardedInterstitialAd.createForAdRequest(AD_IDS.REWARDED_INTERSTITIAL, {
      keywords: ['health', 'fitness', 'habit'],
    })
  ).current;

  useEffect(() => {
    const onLoaded = ad.addAdEventListener(RewardedAdEventType.LOADED,        () => setIsLoaded(true));
    const onEarned = ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD,  (r) => { rewardCb.current?.(r); rewardCb.current = null; });
    const onClosed = ad.addAdEventListener(AdEventType.CLOSED,                () => { setIsLoaded(false); ad.load(); });
    const onError  = ad.addAdEventListener(AdEventType.ERROR,                 (e) => { console.warn('RI err:', e); setIsLoaded(false); });
    ad.load();
    return () => { onLoaded(); onEarned(); onClosed(); onError(); };
  }, []);

  const showAd = async (onReward) => {
    if (!isLoaded) return { success: false, reason: 'not_loaded' };
    rewardCb.current = onReward;
    try { await ad.show(); return { success: true }; }
    catch (e) { rewardCb.current = null; return { success: false, reason: e.message }; }
  };

  return { showAd, isLoaded };
}
